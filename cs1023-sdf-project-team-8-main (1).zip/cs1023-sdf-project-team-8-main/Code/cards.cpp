#include<array>
#include"cards.h"

std::array<int, 3> communityChest = {2, 17, 33};
std::array<int, 3> chance = {8, 22, 36};
std::array<int, 4> corners = {0, 10, 20, 30};